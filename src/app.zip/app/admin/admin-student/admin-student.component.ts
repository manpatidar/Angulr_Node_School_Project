import { Component, OnInit, Input } from '@angular/core';
import { Student } from '../../student'
import { StudentService } from '../../student.service';
import { FormBuilder, FormControl, FormGroup, Validators, NgModel, NgForm } from '@angular/forms';

@Component({
  selector: 'app-admin-student',
  templateUrl: './admin-student.component.html',
  styleUrls: ['./admin-student.component.css']
})
export class AdminStudentComponent implements OnInit {

  classes = ['LKG', 'UKG', 'First', 'Second',
    'Third', 'Fourth', 'Fifth', 'Sixth',
    'Seventh', 'Eighth', 'Ningth', 'Tenth'];
  studentForm: FormGroup;
  selectedStudent: Student = new Student(null, 0, ' ', ' ', ' ', ' ', ' ', 0, 0, 0, 0, 0, 0);
  allStudents: Student[];
  student: Student;
  statusCode: number;
  requestProcessing = false;
  studentIdToUpdate = null;
  processValidation = false;
  isAdd = false;
  isEdit = false;
  isDelete = false;
  showList = false;
  genderList: String[];

  constructor(private fb: FormBuilder, private studentService: StudentService) { }

  ngOnInit(): void {
    this.genderList = ['Male', 'Female', 'Others'];
    this.studentIdToUpdate = null;
    this.studentForm = this.fb.group({

      roll: new FormControl('', [Validators.required, Validators.minLength(1)]),
      fname: new FormControl('', Validators.required),
      lname: new FormControl('', Validators.required),
      faname: new FormControl('', Validators.required),
      gender: new FormControl('', Validators.required),
      clas: new FormControl('', Validators.required),
      hindi: new FormControl('', [Validators.required, Validators.minLength(0), Validators.maxLength(100)]),
      english: new FormControl('', [Validators.required, Validators.minLength(0), Validators.maxLength(50)]),
      science: new FormControl('', [Validators.required, Validators.minLength(0), Validators.maxLength(100)]),
      ssc: new FormControl('', [Validators.required, Validators.minLength(0), Validators.maxLength(100)]),
      maths: new FormControl('', [Validators.required, Validators.minLength(0), Validators.maxLength(100)]),
      sanskrit: new FormControl('', [Validators.required, Validators.minLength(0), Validators.maxLength(50)])
    });
    this.getAllStudents();
  }

  getAllStudents() {
    this.studentService.getAllStudents().subscribe(
      data => this.allStudents = data,
      errorCode => this.statusCode = errorCode);
  }

  onStudentFormSubmit(studentForm: NgForm) {
    this.processValidation = true;
    if (this.studentForm.invalid) {
      return;
    }
    this.preProcessConfigurations();
    let roll = this.studentForm.get('roll').value;
    let fname = this.studentForm.get('fname').value.trim();
    let lname = this.studentForm.get('lname').value.trim();
    let faname = this.studentForm.get('faname').value.trim();
    let clas = this.studentForm.get('clas').value.trim();
    let gender = this.studentForm.get('gender').value;
    let hindi = this.studentForm.get('hindi').value;
    let english = this.studentForm.get('english').value;
    let science = this.studentForm.get('science').value;
    let ssc = this.studentForm.get('ssc').value;
    let maths = this.studentForm.get('maths').value;
    let sanskrit = this.studentForm.get('sanskrit').value;
    if (this.studentIdToUpdate === null) {
      let student = new Student(null, roll, fname, lname, faname, clas, gender, hindi, english, science, ssc, maths, sanskrit);
      this.studentService.createStudent(student)
        .subscribe(successCode => {
          this.statusCode = successCode;
          this.getAllStudents();
          this.backToCreateStudent();
        },
        errorCode => this.statusCode = errorCode);
    }
    else {
      let student1 = new Student(this.studentIdToUpdate, roll, fname, lname, faname, clas, gender, hindi, english, science, ssc, maths, sanskrit);
      this.studentService.updateStudent(student1)
        .subscribe(successCode => {
          this.statusCode = successCode;
          this.getAllStudents();
          this.backToCreateStudent();
        },
        errorCode => this.statusCode = errorCode);
    }
  }

  loadStudentToEdit(studentId: string) {
    this.preProcessConfigurations();
    this.studentService.getStudentById(studentId)
      .subscribe(student => {
        this.studentIdToUpdate = studentId;
        this.studentForm.setValue({
          roll: student.roll, fname: student.fname, lname: student.lname, faname: student.faname, clas: student.clas, gender: student.gender,
          hindi: student.hindi, english: student.english, science: student.science, ssc: student.ssc,
          maths: student.maths, sanskrit: student.sanskrit
        });
        this.processValidation = true;
        this.isDelete = false;
        this.isAdd = false;
        this.isEdit = true;
        this.requestProcessing = false;
        console.log(student.roll, student.fname);
      }, errorCode => this.statusCode = errorCode);
  }

  deleteStudent(studentId: string) {
    this.preProcessConfigurations();
    this.studentService.deleteStudentById(studentId)
      .subscribe(successCode => {
        this.isDelete = true;
        this.isAdd = false;
        this.showList = false;
        this.statusCode = successCode;
        this.getAllStudents();
        this.backToCreateStudent();
      },
      errorCode => this.statusCode = errorCode);
  }
  preProcessConfigurations() {
    this.statusCode = null;
    this.requestProcessing = true;
  }
  backToCreateStudent() {
    this.studentIdToUpdate = null;
    this.processValidation = false;
    this.isDelete = false;
    this.isEdit = false;
    this.isAdd = false;
  }
  changeStatus() {
    this.studentIdToUpdate = null;
    this.isAdd = true;
    this.showList = false;
    this.isEdit = false;
    this.studentForm.reset();
  }
  onSelect(studentId: string) {
    this.studentIdToUpdate = this.loadStudentToEdit(studentId);
    if (this.studentIdToUpdate != ' ') {
      this.isAdd = false;
      this.showList = false;
    }
    else {
      this.isEdit = false;
      this.isAdd = false;
    }
  }
  listAllStudent() {
    this.studentIdToUpdate = null;
    this.showList = true;
    this.isAdd = false;
    this.isEdit = false;
  }
  get roll() { return this.studentForm.get('roll'); }
  get fname() { return this.studentForm.get('fname'); }
  get lname() { return this.studentForm.get('lname'); }
  get faname() { return this.studentForm.get('faname'); }
  get clas() { return this.studentForm.get('clas'); }
  get gender() { return this.studentForm.get('gender'); }
  get hindi() { return this.studentForm.get('hindi'); }
  get english() { return this.studentForm.get('english'); }
  get science() { return this.studentForm.get('science'); }
  get ssc() { return this.studentForm.get('ssc'); }
  get maths() { return this.studentForm.get('maths'); }
  get sanskrit() { return this.studentForm.get('sanskrit'); }

}
