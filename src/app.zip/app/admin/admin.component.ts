import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {

  stdSection = false;
  tchSection = false;
  commSection = false;
constructor(private router: Router ) {  }

ngOnInit() { }
  
changeSection1(){ 
  this.stdSection = true;
  this.tchSection = false;
  this.commSection = false;
}
changeSection2(){ 
  this.stdSection = false;
  this.tchSection = true;
  this.commSection = false;
}
changeSection3(){ 
  this.stdSection = false;
  this.tchSection = false;
  this.commSection = true;
}
}

