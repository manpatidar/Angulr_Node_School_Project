import { Component, Input, Output } from '@angular/core';
//import {Http} from '@angular/http';
import { Teacher } from './teacher';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'app';
  images = ['A.jpg', 'B.jpg',
    'C.jpg', 'D.jpg',
    'E.jpg', 'F.jpg',
    'G.jpg'
  ];
  myCount: boolean = false;
  //@Input() isLoggedIn: boolean = false;
  countChangedHandler(event) {
    console.log("value is app component ", event);
    this.myCount = event;
  }

}
