import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import {HttpModule} from '@angular/http';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { AppRoutingModule } from './/app-routing.module';
import { AboutComponent } from './about/about.component';
import { FeeStructureComponent } from './fee-structure/fee-structure.component';
import { ManagementComponent } from './management/management.component';
import { ContactComponent } from './contact/contact.component';
import { StudentListComponent } from './student-list/student-list.component';
import {StudentService} from './student.service';
import { GalleryComponent } from './gallery/gallery.component';
import { ReactiveFormsModule  } from '@angular/forms';
import { ProgramComponent } from './program/program.component';
import { TeachersComponent } from './teachers/teachers.component';
import { SchoolComponent } from './school/school.component';
import {SlideshowModule} from 'ng-simple-slideshow';
import { LoginComponent } from './login/login.component';
import { ResultComponent } from './result/result.component';
import { AdminComponent } from './admin/admin.component';
import { AdminStudentComponent } from './admin/admin-student/admin-student.component';
import { AdminTeacherComponent } from './admin/admin-teacher/admin-teacher.component';
import { AdminCommiteeComponent } from './admin/admin-commitee/admin-commitee.component';
import { TeacherService } from './teacher.service';
import { MemberService } from './member.service';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    AboutComponent,
    FeeStructureComponent,
    ManagementComponent,
    ContactComponent,
    StudentListComponent,
    GalleryComponent,
    ProgramComponent,
    TeachersComponent,
    SchoolComponent,
    LoginComponent,
    ResultComponent,
    AdminComponent,
    AdminStudentComponent,
    AdminTeacherComponent,
    AdminCommiteeComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    AppRoutingModule,
    HttpModule,
    ReactiveFormsModule,
    SlideshowModule
  ],
  providers: [StudentService,TeacherService,MemberService],
  bootstrap: [AppComponent]
})
export class AppModule { }
