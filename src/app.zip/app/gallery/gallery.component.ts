import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-gallery',
  templateUrl: './gallery.component.html',
  styleUrls: ['./gallery.component.css']
})
export class GalleryComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  images = ['A.jpg', 'B.jpg',
  'C.jpg', 'D.jpg','E.jpg', 'F.jpg','G.jpg','H.jpg',
  'I.jpg','J.jpg','K.jpg','L.jpg','M.jpg', 'N.jpg',
  'O.jpg', 'P.jpg','Q.jpg','R.jpg','U.jpg','V.jpg',
  'W.jpg','X.jpg', 'Y.jpg', 'Z.jpg', 'AA.jpg', 'AB.jpg',
  'AC.jpg','1.jpg', '2.jpg','3.jpg', '4.jpg','5.jpg',
  '6.jpg', '7.jpg', '8.jpg', '9.jpg', '10.jpg','11.jpg',
  '12.jpg','13.jpg', '14.jpg','15.jpg', '16.jpg', '17.jpg',
  '18.jpg', '19.jpg', '20.jpg','21.jpg', '22.jpg','23.jpg',
  '24.jpg','25.jpg','26.jpg', '27.jpg', '28.jpg','29.jpg', 
  '30.jpg','31.jpg',  '32.jpg', '33.jpg', '34.jpg','35.jpg', 
  '36.jpg'
];
}
