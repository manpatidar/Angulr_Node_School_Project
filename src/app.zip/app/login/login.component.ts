import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  user: string;
  pwd: any;
  myForm: FormGroup;
  
  constructor(fb: FormBuilder, private router: Router, ) {
    this.myForm = fb.group({
      'userName': ['', Validators.required],
      'password': ['', Validators.required]
    });
  }
  @Input() count: boolean= false;

  @Output() countChanged = new EventEmitter<boolean>();

  ngOnInit() {  this.myForm.patchValue({
    userName: 'manohar',
    password: '12345'
 });    }

  onSubmit(value: String) {

    this.user = this.myForm.get('userName').value;
    this.pwd = this.myForm.get('password').value;

    if (this.user == 'manohar' && this.pwd == '12345') {
      this.count = true;
      this.countChanged.emit(this.count);
      this.router.navigate(['/admin']);
    }
    else {
      this.count = false;
      this.countChanged.emit(this.count);
    }
  }

}
