import { Injectable } from "@angular/core";
import { Http, Response, Headers, URLSearchParams, RequestOptions } from '@angular/http';
import { Member } from './member';
import { Observable } from 'rxjs';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';

@Injectable()
export class MemberService{

    allMemberUrl = "http://localhost:8080/SpringBootCRUDApp/admin/allmember";
    memberUrl = "http://localhost:8080/SpringBootCRUDApp/admin/member/";
    memberListUrl = "http://localhost:8080/SpringBootCRUDApp/admin/memberlist/";

    constructor(private http: Http){}
    
    getAllMember(): Observable<Member[]>{
        return this.http.get(this.allMemberUrl)
        .map(this.extractData)
        .catch(this.handleError);
    }

    createMember(member:Member):Observable<number>{
        return this.http.post(this.memberUrl, member)
        .map(success => success.status);
    }
    getMemberById(memberId: string):Observable<Member>{
        return this.http.get(this.memberUrl + memberId)
        .map(this.extractData)
            .catch(this.handleError);
    }

    updateMember(member: Member):Observable<number> {
            return this.http.put(this.memberUrl + member.id, member)
                   .map(success => success.status)
                   .catch(this.handleError);
        }
        //Delete Member	
    deleteMemberById(memberId: string): Observable<number> {
        return this.http.delete(this.memberUrl+ memberId)
               .map(success => success.status)
               .catch(this.handleError);
        }	
    private extractData(res: Response) {
            let body = res.json();
                return body;
            }	

    private handleError(error: Response | any){
        console.error(error.message || error);
        return Observable.throw(error.status);
    }
}