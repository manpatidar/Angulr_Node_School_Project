/* import { Teacher} from './teacher';

export const TEACHER: Teacher[] = [
    { id: 1, name: 'Mr. Durgesh Panchal', DESG: 'M.A.', DOB: '01-01-2000',DOJ: '01-01-2000' },
    { id: 2, name: 'Mr. Prabhulal Parmar',DESG: 'M.A.', DOB: '01-01-2000',DOJ: '01-01-2000' },
    { id: 3, name: 'Mr. Surendra Rathore', DESG: 'M.A.',DOB: '01-01-2000',DOJ: '01-01-2000' },
    { id: 4, name: 'Mr. Shyamlal Keer',DESG: 'M.A.', DOB: '01-01-2000',DOJ: '01-01-2000' },
    { id: 5, name: 'Mrs. Urmila Vyas',DESG: 'M.A.', DOB: '01-01-2000',DOJ: '01-01-2000' },
    { id: 6, name: 'Mr. Hiralal Mandwar',DESG: 'M.A.', DOB: '01-01-2000',DOJ: '01-01-2000' },
    { id: 7, name: 'Mr. Samrathmal Kapasiya',DESG: 'M.A.', DOB: '01-01-2000',DOJ: '01-01-2000' },
    { id: 8, name: 'Mr. Dharmendra Patidar',DESG: 'M.A.', DOB: '01-01-2000',DOJ: '01-01-2000' },
    { id: 9, name: 'Mr. Deepak Patidar',DESG: 'M.A.', DOB: '01-01-2000',DOJ: '01-01-2000' },
    { id: 10, name: 'Ms. Girija Kuwar Chandrawat',DESG: 'M.A.', DOB: '01-01-2000',DOJ: '01-01-2000' },
    { id: 11, name: 'Ms. Padma Patidar',DESG: 'M.A.', DOB: '01-01-2000',DOJ: '01-01-2000' },
    { id: 12, name: 'Mr. Vinod Patidar',DESG: 'M.A.', DOB: '01-01-2000',DOJ: '01-01-2000' },
    { id: 13, name: 'Mrs. Koushalya Shah',DESG: 'M.A.', DOB: '01-01-2000',DOJ: '01-01-2000' },
    { id: 14, name: 'Mrs. Bhawna Rawal',DESG: 'M.A.', DOB: '01-01-2000',DOJ: '01-01-2000' },
    { id: 15, name: 'Mrs. Bindu Rawal',DESG: 'M.A.', DOB: '01-01-2000',DOJ: '01-01-2000' },
    { id: 16, name: 'Mr. Ritesh Prajapat',DESG: 'M.A.', DOB: '01-01-2000',DOJ: '01-01-2000' },
    { id: 17, name: 'Mr. Rakesh Puri Goswami',DESG: 'M.A.', DOB: '01-01-2000',DOJ: '01-01-2000' },
    { id: 18, name: 'Mrs. Mamta Patidar',DESG: 'M.A.', DOB: '01-01-2000',DOJ: '01-01-2000' },
    { id: 19, name: 'Mr. Bansilal Malviya',DESG: 'M.A.', DOB: '01-01-2000',DOJ: '01-01-2000' },
    { id: 20  , name: 'Mrs. Anita Patidar',DESG: 'M.A.', DOB: '01-01-2000',DOJ: '01-01-2000' }
  ]; */