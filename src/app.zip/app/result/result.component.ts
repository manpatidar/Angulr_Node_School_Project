import { Component, OnInit } from '@angular/core';
import { Student } from '../student';
import { StudentService } from '../student.service';
import { FormControl, FormGroup, Validators, NgModel } from '@angular/forms';

@Component({
  selector: 'app-result',
  templateUrl: './result.component.html',
  styleUrls: ['./result.component.css']
})
export class ResultComponent implements OnInit {


  student : Student;
  studentId = null;
  statusCode : number;
  isValid = false;
  rolln:number;
  total:number;
  resultForm = new FormGroup({
    roll: new FormControl(0),
    fname: new FormControl(''),
    lname: new FormControl(''),
    faname: new FormControl(''),
    clas: new FormControl(''),
    hindi: new FormControl(0),
    english: new FormControl(0),
    science: new FormControl(0),
    ssc: new FormControl(0),
    maths: new FormControl(0),
    sanskrit: new FormControl(0)
  });

  constructor(private studentService: StudentService) { }

  ngOnInit() { 
  } 
  onSubmit(data: string){
    
    this.rolln = this.resultForm.get('roll').value;
    console.log(this.rolln);
    this.studentService.getResultByRoll(this.rolln)
    .subscribe(student => {
        this.studentId = this.studentId; 
        this.resultForm.setValue({roll:student.roll,fname:student.fname,lname:student.lname,faname:student.faname, clas:student.clas,
        hindi:student.hindi,english:student.english,science:student.science,ssc:student.ssc,
        maths:student.maths,sanskrit:student.sanskrit});
        this.isValid = true;
        this.total = student.hindi + student.english + student.science + student.ssc + student.maths + student.sanskrit;  
    },errorCode =>  this.statusCode = errorCode);
  }


}


