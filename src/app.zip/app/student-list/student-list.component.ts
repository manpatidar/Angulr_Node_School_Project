import { Component, OnInit, Input } from '@angular/core';
import { Student } from '../student';
import { StudentService } from '../student.service';

@Component({
  selector: 'app-student-list',
  templateUrl: './student-list.component.html',
  styleUrls: ['./student-list.component.css']
})
export class StudentListComponent implements OnInit {

  classes = ['LKG', 'UKG', 'First', 'Second',
    'Third', 'Fourth', 'Fifth', 'Sixth',
    'Seventh', 'Eighth', 'Ningth', 'Tenth'];

  available = false;
  student: Student[];
  statusCode : number;
  constructor(private studentService: StudentService) { }

  ngOnInit() {

  }
  onSelect(className: string) {
    if (className != '') {
      this.studentService.loadStudentListByClass(className).
        subscribe(allStudents => { this.student = allStudents },
          errorCode => this.statusCode = errorCode);
          console.log(this.student);
       if(this.student!=null){
          this.available = true;
       }   
    }
    console.log(className);
  }
}
