import { Injectable } from "@angular/core";
import { Http, Response, Headers, URLSearchParams, RequestOptions } from '@angular/http';
import { Student } from './student';
import { Observable } from 'rxjs';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';

@Injectable()
export class StudentService {

    allStudentUrl = "http://localhost:8080/SpringBootCRUDApp/api/allstudent";
    studentUrl = "http://localhost:8080/SpringBootCRUDApp/api/student/";
    resultUrl = "http://localhost:8080/SpringBootCRUDApp/api/result/";
    stdListUrl = "http://localhost:8080/SpringBootCRUDApp/api/studentlist/";

    constructor(private http: Http) { }

    getAllStudents(): Observable<Student[]> {
        return this.http.get(this.allStudentUrl)
            .map(this.extractData)
            .catch(this.handleError);
    }
    createStudent(student: Student): Observable<number> {
        return this.http.post(this.studentUrl, student)
            .map(success => success.status);
    }
    updateStudent(student: Student): Observable<number> {
        return this.http.put(this.studentUrl + student.id, student)
            .map(success => success.status)
            .catch(this.handleError);
    }
    deleteStudentById(studentId: string): Observable<number> {
        return this.http.delete(this.studentUrl + studentId)
            .map(success => success.status)
            .catch(this.handleError);
    }
    getStudentById(studentId: string): Observable<Student> {
        return this.http.get(this.studentUrl + studentId)
            .map(this.extractData)
            .catch(this.handleError);
    }
    getResultByRoll(rollnumber: number): Observable<Student> {
        return this.http.get(this.resultUrl + rollnumber)
            .map(this.extractData)
            .catch(this.handleError);
    }
    loadStudentListByClass(className: string): Observable<Student[]> {
        return this.http.get(this.stdListUrl + className)
            .map(this.extractData)
            .catch(this.handleError);
    }
    private extractData(res: Response) {
        let body = res.json();
        return body;
    }

    private handleError(error: Response | any) {
        console.error(error.message || error);
        return Observable.throw(error.status);
    }
}