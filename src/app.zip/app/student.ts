export class Student{
  constructor(public id: string, 
              public roll: number,
              public fname: string, 
              public lname: string,
              public faname: string, 
              public clas: string,
              public gender: string,
              public hindi: number, 
              public english: number,
              public science: number, 
              public ssc: number,
              public maths: number,
              public sanskrit: number
            ) {
  
          
      }
  
}