  import { Injectable } from "@angular/core";
  import { Http, Response, Headers, URLSearchParams, RequestOptions } from '@angular/http';
  import { Teacher } from './teacher';
  import { Observable } from 'rxjs';
  import 'rxjs/add/operator/map';
  import 'rxjs/add/operator/catch';
  
  @Injectable()
  export class TeacherService{
  
      allTeacherUrl = "http://localhost:8080/SpringBootCRUDApp/admin/allteacher";
      teacherUrl = "http://localhost:8080/SpringBootCRUDApp/admin/teacher/";
      teacherListUrl = "http://localhost:8080/SpringBootCRUDApp/admin/teacherlist/";
  
      constructor(private http: Http){}
      
      getAllTeacher(): Observable<Teacher[]>{
          return this.http.get(this.allTeacherUrl)
          .map(this.extractData)
          .catch(this.handleError);
      }
  
      createTeacher(teacher:Teacher):Observable<number>{
          return this.http.post(this.teacherUrl, teacher)
          .map(success => success.status);
      }
      getTeacherById(teacherId: string):Observable<Teacher>{
          return this.http.get(this.teacherUrl + teacherId)
          .map(this.extractData)
              .catch(this.handleError);
      }
  
      updateTeacher(teacher: Teacher):Observable<number> {
              return this.http.put(this.teacherUrl + teacher.id, teacher)
                     .map(success => success.status)
                     .catch(this.handleError);
          }
          //Delete Teacher	
      deleteTeacherById(teacherId: string): Observable<number> {
          return this.http.delete(this.teacherUrl+ teacherId)
                 .map(success => success.status)
                 .catch(this.handleError);
          }	
      private extractData(res: Response) {
              let body = res.json();
                  return body;
              }	
  
      private handleError(error: Response | any){
          console.error(error.message || error);
          return Observable.throw(error.status);
      }
  }