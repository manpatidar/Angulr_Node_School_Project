export class Teacher{
    constructor(public id: number, 
                public fname: string,
                public lname: string, 
                public post: string,
                public qual: string
                ) {
    
            
        }
    
  }